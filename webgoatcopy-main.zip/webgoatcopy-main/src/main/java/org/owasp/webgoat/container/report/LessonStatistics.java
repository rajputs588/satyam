package org.owasp.webgoat.container.report;

record LessonStatistics(String name, boolean solved, int numberOfAttempts) {}
