CREATE TABLE salaries(
  userid varchar(50),
  salary int
);

INSERT INTO salaries VALUES ('jsmith', 20000);
INSERT INTO salaries VALUES ('lsmith', 45000);
INSERT INTO salaries VALUES ('wgoat', 100000);
INSERT INTO salaries VALUES ('rjones', 777777);
INSERT INTO salaries VALUES ('manderson', 65000);
